#ifndef BSP_CAN_H
#define BSP_CAN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "can.h"

/**
 * @brief CAN接收的信息结构体
 *
 */
typedef struct {
    CAN_RxHeaderTypeDef Header;
    uint8_t Data[8];
} Struct_CAN_Rx_Buffer;

/**
 * @brief CAN通信接收回调函数数据类型
 *
 */
typedef void (*CAN_Call_Back) (Struct_CAN_Rx_Buffer*);

/**
 * @brief CAN通信处理结构体
 *
 */
typedef struct {
    CAN_HandleTypeDef *CAN_Handler;
    Struct_CAN_Rx_Buffer Rx_Buffer;
    CAN_Call_Back Callback_Function;
} Struct_CAN_Manage_Object;

extern Struct_CAN_Manage_Object CAN1_Manage_Object;
extern Struct_CAN_Manage_Object CAN2_Manage_Object;

extern uint8_t CAN1_0x1fe_Tx_Data[8];
extern uint8_t CAN1_0x1ff_Tx_Data[8];
extern uint8_t CAN1_0x200_Tx_Data[8];
extern uint8_t CAN1_0x2fe_Tx_Data[8];

extern uint8_t CAN1_0x141_Tx_Data[8];

extern uint8_t CAN2_0x1fe_Tx_Data[8];
extern uint8_t CAN2_0x1ff_Tx_Data[8];
extern uint8_t CAN2_0x200_Tx_Data[8];
extern uint8_t CAN2_0x2fe_Tx_Data[8];

void Can_Filter_Mask_Config(CAN_HandleTypeDef *hcan, uint32_t ID, uint32_t Mask_ID);

void CAN_Init(CAN_HandleTypeDef *hcan,CAN_Call_Back Callback_Function);

uint8_t CAN_Send_Data(CAN_HandleTypeDef *hcan, uint16_t ID, uint8_t *Data, uint16_t Length);

#ifdef __cplusplus
}
#endif

#endif