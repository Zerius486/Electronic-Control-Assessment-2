#ifndef ALG_MATH_H
#define ALG_MATH_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

void Current_To_16Bits(float Current_Val, uint8_t* output);

#ifdef __cplusplus
}
#endif

#endif