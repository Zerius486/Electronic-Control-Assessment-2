#include "alg_pid.h"

PID_Controller pid1;

/**
 * @brief 初始化PID控制器
 *
 * @param pid PID控制器
 * @param Kp 比例项系数
 * @param Ki 积分项系数
 * @param Kd 微分项系数
 * @param output_max 输出上限
 * @param output_min 输出下限
 * @param integral_max 积分上限
 * @param integral_min 积分下限
 * @param dead_zone 死区
 * @param target 目标值
 * @param i_decay 死区内积分项衰减速率
 */
void PID_Controller_Init(PID_Controller* pid, float Kp, float Ki, float Kd, float output_max, float output_min, float integral_max, float integral_min, float dead_zone, float target, float i_decay) {
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->i_decay = i_decay;
    pid->output_max = output_max;
    pid->output_min = output_min;
    pid->integral_max = integral_max;
    pid->integral_min = integral_min;
    pid->dead_zone = dead_zone;
    pid->target = target;
    pid->error = 0.0f;
    pid->integral = 0.0f;
    pid->last_error = 0.0f;
    pid->output = 0.0f;
}

/**
 * @brief 计算当次输出
 *
 * @param pid PID控制器
 * @param input 输入
 */
float PID_Controller_Calculate(PID_Controller* pid, float input) {
    pid->last_error = pid->error;
    pid->error = pid->target - input;

    pid->integral = pid->integral + pid->error;

    if (pid->integral > pid->integral_max) {
        pid->integral = pid->integral_max;
    } else if (pid->integral < pid->integral_min) {
        pid->integral = pid->integral_min;
    }

    float output = pid->Ki * pid->integral + pid->Kp * pid->error + pid->Kd * (pid->error - pid->last_error);

    if (output > pid->output_max) {
        output = pid->output_max;
    } else if (output < pid->output_min) {
        output = pid->output_min;
    }

    if (pid->error < pid->dead_zone && pid->error > -pid->dead_zone) {
        pid->integral = pid->integral * pid->i_decay;
        pid->last_error = pid->error;
        return 0;
    } else {
        return output;
    }
}