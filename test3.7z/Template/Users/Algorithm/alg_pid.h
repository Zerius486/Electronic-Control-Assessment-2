#ifndef ALG_PID_H
#define ALG_PID_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief PID控制器结构体
 *
 * @param Ki 积分项系数
 * @param Kp 比例项系数
 * @param Kd 微分项系数
 * @param error 误差
 * @param last_error 上次误差
 * @param integral 积分项
 * @param output 输出
 * @param output_max 输出上限
 * @param output_min 输出下限
 * @param integral_max 积分上限
 * @param integral_min 积分下限
 * @param dead_zone 死区
 * @param target 目标值
 * @param i_decay 死区内积分项衰减速率
 */
typedef struct {
    float Ki;
    float Kd;
    float Kp;

    float error;
    float last_error;
    float integral;

    float output;

    float output_max;
    float output_min;

    float integral_max;
    float integral_min;

    float dead_zone;
    float target;
    float i_decay;
} PID_Controller;

void PID_Controller_Init(PID_Controller* pid, float Kp, float Ki, float Kd, float output_max, float output_min, float integral_max, float integral_min, float dead_zone, float target, float i_decay);

float PID_Controller_Calculate(PID_Controller* pid, float input);

extern PID_Controller pid1;

#ifdef __cplusplus
}
#endif

#endif