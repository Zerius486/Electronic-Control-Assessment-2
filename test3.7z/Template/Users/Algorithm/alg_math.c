#include "alg_math.h"

/**
 * @brief 电流值转换为16位整数
 *
 * @param Current_Val 电流值
 * @param output 转换值
 */
void Current_To_16Bits(float Current_Val, uint8_t* output) {
  int16_t temp_val = (int16_t)(Current_Val * 1000.0f);

  // 电流限幅
  if (temp_val > 10000) {
    temp_val = 10000;
  } else if (temp_val < -10000) {
    temp_val = -10000;
  }

  output[0] = (temp_val >> 8) & 0xFF;
  output[1] = (temp_val & 0xFF);
}