#include "m3508.h"

m3508_status motor1;

/**
 * @brief 向电调ID为1-4的m3508电机写入电流
 *
 * @param hcan 使用的CAN句柄
 * @param current1 1号电调写入的电流
 * @param current2 2号电调写入的电流
 * @param current3 3号电调写入的电流
 * @param current4 4号电调写入的电流
 */
void Set_m3508_Current1(CAN_HandleTypeDef* hcan, float current1, float current2, float current3, float current4) {
    // 转换电流值
    uint8_t temp_vsl1[2];
    uint8_t temp_vsl2[2];
    uint8_t temp_vsl3[2];
    uint8_t temp_vsl4[2];
    Current_To_16Bits(current1, temp_vsl1);
    Current_To_16Bits(current2, temp_vsl2);
    Current_To_16Bits(current3, temp_vsl3);
    Current_To_16Bits(current4, temp_vsl4);

    // 打包发送数据
    uint8_t data[8];
    data[0] = temp_vsl1[0];
    data[1] = temp_vsl1[1];
    data[2] = temp_vsl2[0];
    data[3] = temp_vsl2[1];
    data[4] = temp_vsl3[0];
    data[5] = temp_vsl3[1];
    data[6] = temp_vsl4[0];
    data[7] = temp_vsl4[1];

    if (CAN_Send_Data(hcan, 0x200, data, 8) != HAL_OK) {
        Error_Handler();
    }
}

/**
 * @brief 向电调ID为5-8的m3508电机写入电流
 *
 * @param hcan 使用的CAN句柄
 * @param current5 5号电调写入的电流
 * @param current6 6号电调写入的电流
 * @param current7 7号电调写入的电流
 * @param current8 8号电调写入的电流
 */
void Set_m3508_Current2(CAN_HandleTypeDef* hcan, float current5, float current6, float current7, float current8) {
    // 转换电流值
    uint8_t temp_vsl5[2];
    uint8_t temp_vsl6[2];
    uint8_t temp_vsl7[2];
    uint8_t temp_vsl8[2];
    Current_To_16Bits(current5, temp_vsl5);
    Current_To_16Bits(current6, temp_vsl6);
    Current_To_16Bits(current7, temp_vsl7);
    Current_To_16Bits(current8, temp_vsl8);

    // 打包发送数据
    uint8_t data[8];
    data[0] = temp_vsl5[0];
    data[1] = temp_vsl5[1];
    data[2] = temp_vsl6[0];
    data[3] = temp_vsl6[1];
    data[4] = temp_vsl7[0];
    data[5] = temp_vsl7[1];
    data[6] = temp_vsl8[0];
    data[7] = temp_vsl8[1];

    if (CAN_Send_Data(hcan, 0x1FF, data, 8) != HAL_OK) {
        Error_Handler();
    }
}

/**
 * @brief m3508电机初始化
 *
 * @param motor m3508电机结构体
 * @param id 电机电调对应ID
 */
void m3508_Init(m3508_status* motor, uint32_t id) {
    motor->id = id;
    motor->current = 0.0f;
    motor->angle = 0.0f;
    motor->rpm = 0;
    motor->temperature = 0.0f;
    motor->error_code = 0;
}

/**
 * @brief  解析电机数据并更新状态
 *
 * @param motor m3508电机状态结构体
 * @param data CAN接收的数据
 */
void m3508_Status_Update(m3508_status* motor, uint8_t* data) {
    // 接收原始数据
    int16_t angle_raw = (data[0] << 8) | data[1];
    int16_t rpm_raw = (data[2] << 8) | data[3];
    int16_t current_raw = (data[4] << 8) | data[5];
    int16_t temperature_raw = data[6];
    int16_t error_raw = data[7];

    // 更新结构体
    motor->current = current_raw * 0.001f;
    motor->angle = angle_raw * (360.0f / 8192.0f);
    motor->rpm = rpm_raw;
    motor->temperature = temperature_raw * 1.0f;
    motor->error_code = error_raw;
}

/**
 * @brief CAN接收回调函数(目前只处理电调ID为0x201的电机)
 *
 * @param buffer 接收缓冲区
 */
void CAN_Receive_Callback_m3508(Struct_CAN_Rx_Buffer* buffer)
{
    if (buffer->Header.StdId == 0x201) {
        m3508_Status_Update(&motor1, buffer->Data);
    }
}