#include "vofa.h"

// VOFA命令缓冲区
uint8_t vofa_cmd_buffer[VOFA_CMD_MAX_LEN];
static uint8_t cmd_buffer_pos = 0;
static uint8_t cmd_head_pos = 0;

// PID更新消息
static uint32_t last_send_time = 0;    // 上次发送时间
static uint32_t send_interval = 10;    // 发送间隔(ms)

/**
 * @brief 初始化VOFA接口
 *
 * @param huart 启用的UART通信句柄
 */
void Vofa_Init(UART_HandleTypeDef *huart)
{
    // 清空命令缓冲区
    memset(vofa_cmd_buffer, 0, sizeof(vofa_cmd_buffer));
    cmd_buffer_pos = 0;
    cmd_head_pos = 0;

    // 发送连接成功消息
    VOFA_PRINTF("VOFA+ Connected Successfully!\r\n");

    // 发送初始化参数
    VOFA_PRINTF("PID Init: Kp=%.2f, Ki=%.2f, Kd=%.2f\r\n", pid1.Kp, pid1.Ki, pid1.Kd);
}

/**
 * @brief 发送数据到VOFA
 *
 * @param data_flag 内容类型
 */
void Vofa_Send_Data(uint8_t data_flag)
{
    uint32_t current_time = HAL_GetTick();

    // 控制发送频率
    if (current_time - last_send_time < send_interval) {
        return;
    }

    last_send_time = current_time;

    switch(data_flag) {
        case VOFA_PID_MOTOR_DATA:
            // 发送PID和电机基本数据
            VOFA_PRINTF("%.2f,%.2f,%.2f,%.2f,%.2f,%d\n",
                       pid1.target,               // 目标转速
                       (float)motor1.rpm,         // 实际转速
                       pid1.Kp,                   // 比例系数
                       pid1.Ki,                   // 积分系数
                       pid1.Kd,                   // 微分系数
                       motor1.error_code);        // 错误码
            break;

        case VOFA_PID_DETAIL_DATA:
            // 发送PID详细数据
            VOFA_PRINTF("%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f\n",
                       pid1.target,               // 目标值
                       pid1.output,               // PID输出
                       pid1.integral,             // 积分项
                       pid1.error,                // 当前误差
                       pid1.last_error,           // 上次误差
                       pid1.Kp * pid1.error,      // P项输出
                       pid1.Ki * pid1.integral);  // I项输出
            break;

        case VOFA_MOTOR_STATUS_DATA:
            /* 发送电机状态数据 */
            VOFA_PRINTF("%d,%.2f,%.2f,%d\n",
                       motor1.rpm,                // 转速
                       motor1.angle,              // 角度
                       motor1.current,            // 电流
                       motor1.error_code);        // 错误码
            break;

        default:
            break;
    }
}

/**
 * @brief 处理VOFA命令字符串
 *
 * @param cmd_str 命令字符串
 */
static void Vofa_Process_Command(const char* cmd_str)
{
    if (strlen(cmd_str) < 3) {
        return;
    }

    // 解析命令ID和值
    char cmd_type = cmd_str[0];
    char cmd_index = cmd_str[1];
    char* equal_pos = strchr(cmd_str, '=');

    if (equal_pos == NULL || equal_pos == cmd_str) {
        return;
    }

    // 提取数值
    float value = atof(equal_pos + 1);

    // 处理命令
    if (cmd_index == '1') {  // PID1控制器
        switch(cmd_type) {
            case 'P':  // 设置比例系数
                pid1.Kp = value;
                VOFA_PRINTF("Set Kp=%.3f\n", value);
                break;

            case 'I':  // 设置积分系数
                pid1.Ki = value;
                VOFA_PRINTF("Set Ki=%.3f\n", value);
                break;

            case 'D':  // 设置微分系数
                pid1.Kd = value;
                VOFA_PRINTF("Set Kd=%.3f\n", value);
                break;

            case 'T':  // 设置目标值
                pid1.target = value;
                VOFA_PRINTF("Set Target=%.1f RPM\n", value);
                break;

            case 'Z':  // 设置死区
                pid1.dead_zone = value;
                VOFA_PRINTF("Set DeadZone=%.2f\n", value);
                break;

            case 'X':  // 设置积分衰减
                pid1.i_decay = value;
                VOFA_PRINTF("Set I_Decay=%.2f\n", value);
                break;

            case 'M':  // 设置输出上限
                if (value > pid1.output_min) {
                    pid1.output_max = value;
                    VOFA_PRINTF("Set OutputMax=%.1f\n", value);
                }
                break;

            case 'N':  // 设置输出下限
                if (value < pid1.output_max) {
                    pid1.output_min = value;
                    VOFA_PRINTF("Set OutputMin=%.1f\n", value);
                }
                break;

            case 'S':  // 设置发送间隔
                if (value >= 1 && value <= 1000) {
                    send_interval = (uint32_t)value;
                    VOFA_PRINTF("Set SendInterval=%dms\n", send_interval);
                }
                break;

            default:
                break;
        }
    }
}

/**
 * @brief UART接收回调函数
 *
 * @param buffer 接收缓冲区
 * @param length 接收长度
 */
void Vofa_UART_Callback(uint8_t *buffer, uint16_t length)
{
    static uint8_t rx_buffer[VOFA_CMD_MAX_LEN];
    static uint16_t rx_index = 0;

    for (uint16_t i = 0; i < length; i++) {
        uint8_t rx_byte = buffer[i];

        // 回车或换行符表示命令结束
        if (rx_byte == '\n' || rx_byte == '\r') {
            if (rx_index > 0) {
                rx_buffer[rx_index] = '\0';  // 添加字符串结束符
                Vofa_Process_Command((char*)rx_buffer);
                rx_index = 0;
            }
            // 跳过连续的回车换行符
            continue;
        }

        // 存储有效字符
        if (rx_index < sizeof(rx_buffer) - 1) {
            rx_buffer[rx_index++] = rx_byte;
        }
        else {
            // 缓冲区溢出，重置
            rx_index = 0;
            rx_buffer[0] = '\0';
        }
    }
}