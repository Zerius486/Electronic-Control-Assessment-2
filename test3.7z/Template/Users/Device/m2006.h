#ifndef M2006_H
#define M2006_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include "bsp_can.h"
#include "alg_math.h"

/**
 * @brief m2006电机状态结构体
 *
 * @param angle 机械角度
 * @param current 转轴电流
 * @param rpm 转速
 * @param error_code 错误码
 * @param id 电调ID
 */
typedef struct {
    float angle;
    float current;
    int16_t rpm;
    int8_t error_code;
    uint32_t id;
} m2006_status;

void m2006_Init(m2006_status* motor, uint32_t id);

void Set_m2006_Current1(CAN_HandleTypeDef* hcan, float current1, float current2, float current3, float current4);

void Set_m2006_Current2(CAN_HandleTypeDef* hcan, float current5, float current6, float current7, float current8);

void m2006_Status_Update(m2006_status* motor, uint8_t* data);

void CAN_Receive_Callback_m2006(Struct_CAN_Rx_Buffer* buffer);

#ifdef __cplusplus
}
#endif

#endif