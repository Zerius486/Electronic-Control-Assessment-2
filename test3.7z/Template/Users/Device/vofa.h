#ifndef VOFA_H
#define VOFA_H

#ifdef __cplusplus
extern "C" {
#endif

#include "bsp_uart.h"
#include "alg_pid.h"
#include "m2006.h"
#include "m3508.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


// VOFA数据发送相关
#define VOFA_DATA_FORMAT "FireWater"

// 数据类型标识
#define VOFA_PID_MOTOR_DATA      0  // 发送PID和电机数据
#define VOFA_PID_DETAIL_DATA     1  // 发送PID详细数据
#define VOFA_MOTOR_STATUS_DATA   2  // 发送电机状态数据

// VOFA命令接收相关
#define VOFA_CMD_HEAD    '='     // 命令帧头
#define VOFA_CMD_END     '\n'    // 命令帧尾
#define VOFA_CMD_MAX_LEN 100     // 命令最大长度

/**
 * @brief   VOFA格式化输出宏定义
 *
 * @note    根据实际硬件修改为对应的UART发送函数，这里是USART6
 */
#define VOFA_PRINTF(...) \
do { \
    static char vofa_buf[256]; \
    static uint8_t buf_lock = 0; \
    while(buf_lock) { \
      __NOP(); \
    } \
    buf_lock = 1; \
    int len = snprintf(vofa_buf, sizeof(vofa_buf), __VA_ARGS__); \
    if (len > 0 && len < sizeof(vofa_buf)) { \
        uint32_t timeout = HAL_GetTick(); \
        while(HAL_UART_GetState(&huart6) == HAL_UART_STATE_BUSY_TX) { \
            if (HAL_GetTick() - timeout > 100) break; \
        } \
        HAL_UART_Transmit(&huart6, (uint8_t*)vofa_buf, len, 1000); \
    } \
    buf_lock = 0; \
} while(0)


// 全局缓冲区
extern uint8_t vofa_cmd_buffer[VOFA_CMD_MAX_LEN];

void Vofa_Init(UART_HandleTypeDef *huart);

void Vofa_Send_Data(uint8_t data_flag);

void Vofa_UART_Callback(uint8_t *buffer, uint16_t length);

#ifdef __cplusplus
}
#endif

#endif