#ifndef BSP_CAN_H
#define BSP_CAN_H

#ifdef __cplusplus
extern "C" {
#endif

/* ========== 包含头文件 ========== */

#include "bsp_config.h"
#include "stm32f4xx_hal.h"

/* ========== 函数声明 ========== */

// CAN滤波器配置函数
void CAN_Filter_Init(CAN_HandleTypeDef* hcan, uint32_t filter_id);

// CAN初始化函数
void CAN_Init(CAN_HandleTypeDef* hcan);

// CAN发送数据函数
HAL_StatusTypeDef CAN_Send(CAN_HandleTypeDef* hcan, uint32_t id, uint8_t* data, uint8_t len, uint8_t is_ext);

// CAN接收中断回调函数
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef* hcan);

#ifdef __cplusplus
}
#endif

#endif