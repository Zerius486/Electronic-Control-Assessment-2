#ifndef BSP_CONFIG_H
#define BSP_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

/* ========== 包含头文件 ========== */

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <stddef.h>

/* ========== 全局变量定义 ========== */

// 滤波器ID
extern uint32_t Filter1_ID;
extern uint32_t Filter2_ID;

// 接收数据缓存
extern CAN_RxHeaderTypeDef g_rx_header;
extern uint8_t g_rx_data[8];

#ifdef __cplusplus
}
#endif

#endif