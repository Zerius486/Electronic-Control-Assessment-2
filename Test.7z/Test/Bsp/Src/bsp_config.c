#include "bsp_config.h"

// 滤波器ID
uint32_t Filter1_ID;
uint32_t Filter2_ID;

// 接收数据缓存
CAN_RxHeaderTypeDef g_rx_header;
uint8_t g_rx_data[8] = {0};