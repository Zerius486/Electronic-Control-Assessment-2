#include "bsp_config.h"
#include "bsp_can.h"

// 声明CAN句柄
extern CAN_HandleTypeDef hcan1;
extern CAN_HandleTypeDef hcan2;

// CAN滤波器配置函数
void CAN_Filter_Init(CAN_HandleTypeDef* hcan, uint32_t filter_id) {
    CAN_FilterTypeDef CAN_FilterConfigStructure;

    if (hcan->Instance == CAN1) {
        CAN_FilterConfigStructure.FilterBank = 0;
    } else if (hcan->Instance == CAN2) {
        CAN_FilterConfigStructure.FilterBank = 14;
    } else {
        return;
    }

    CAN_FilterConfigStructure.FilterBank = 14;
    CAN_FilterConfigStructure.FilterMode = CAN_FILTERMODE_IDMASK;
    CAN_FilterConfigStructure.FilterScale = CAN_FILTERSCALE_32BIT;
    CAN_FilterConfigStructure.FilterIdHigh = (filter_id >> 13) & 0xFFFF;
    CAN_FilterConfigStructure.FilterIdLow = (filter_id << 3) & 0xFFFF;
    CAN_FilterConfigStructure.FilterMaskIdHigh = 0xFFFF;
    CAN_FilterConfigStructure.FilterMaskIdLow = 0xFFFF;
    CAN_FilterConfigStructure.FilterFIFOAssignment = CAN_FilterFIFO0;
    CAN_FilterConfigStructure.FilterActivation = ENABLE;

    if (HAL_CAN_ConfigFilter(hcan, &CAN_FilterConfigStructure) != HAL_OK) {
        return;
    }
}

// CAN初始化函数
void CAN_Init(CAN_HandleTypeDef* hcan) {
    
    if (hcan->Instance == CAN1) {
        CAN_Filter_Init(hcan, Filter1_ID);
    } else if (hcan->Instance == CAN2) {
        CAN_Filter_Init(hcan, Filter2_ID);
    } else {
        return;
    }
    
    HAL_CAN_Start(hcan);
    HAL_CAN_ActivateNotification(hcan, CAN_IT_RX_FIFO0_MSG_PENDING);
}

// CAN发送数据函数
HAL_StatusTypeDef CAN_Send(CAN_HandleTypeDef* hcan, uint32_t id, uint8_t* data, uint8_t len, uint8_t is_ext) {

    CAN_TxHeaderTypeDef TxHeader;
    uint32_t TxMailbox;

    if (data == NULL || len > 8) {
        return HAL_ERROR;
    }

    if (is_ext) {
        TxHeader.ExtId = id;
        TxHeader.IDE = CAN_ID_EXT;
        TxHeader.StdId = 0;
    } else {
        TxHeader.StdId = id;
        TxHeader.IDE = CAN_ID_STD;
        TxHeader.ExtId = 0;
    }

    TxHeader.RTR = CAN_RTR_DATA;
    TxHeader.DLC = len;
    TxHeader.TransmitGlobalTime = DISABLE;

    return HAL_CAN_AddTxMessage(hcan, &TxHeader, data, &TxMailbox);
}

// CAN接收中断回调函数
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef* hcan) {
    
    CAN_RxHeaderTypeDef rx_header;
    uint8_t rx_data[8] = {0};

    if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data) != HAL_OK) {
        return;
    }

    g_rx_header = rx_header;
    for (int i = 0; i < 8; i++) {
        g_rx_data[i] = rx_data[i];
    }
}