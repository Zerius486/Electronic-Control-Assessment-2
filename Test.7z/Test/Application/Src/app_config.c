#include "app_config.h"

Motor motor1;