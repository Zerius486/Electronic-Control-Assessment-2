#include "app_config.h"
#include "bsp_config.h"
#include "app_motor.h"
#include "bsp_can.h"

// 电机初始化函数
void Motor_Init(Motor* motor, uint8_t motor_type) {
    motor->motor_type = motor_type;

    // 根据电机类型初始化状态
    switch (motor_type) {
        case MOTOR_TYPE_M2006:
            // 初始化 M2006 电机状态
            motor->status.m2006.angle_deg = 0.0f;
            motor->status.m2006.speed_rpm = 0;
            motor->status.m2006.current_a = 0.0f;
            motor->status.m2006.error_code = 0;
            break;
        case MOTOR_TYPE_M3508:
            // 初始化 M3508 电机状态
            motor->status.m3508.angle_deg = 0.0f;
            motor->status.m3508.speed_rpm = 0;
            motor->status.m3508.current_a = 0.0f;
            motor->status.m3508.temperature_c = 0;
            motor->status.m3508.error_code = 0;
            break;
        case MOTOR_TYPE_GM6020:
            // 初始化 GM6020 电机状态
            motor->status.gm6020.angle_deg = 0.0f;
            motor->status.gm6020.speed_rpm = 0;
            motor->status.gm6020.current_a = 0.0f;
            motor->status.gm6020.temperature_c = 0;
            break;
        default:
            // 错误处理
            break;
    }
}

// 电机状态更新函数
void Motor_UpdateStatus(Motor *motor, uint8_t* data) {
    // 根据motor->motor_type来判断电机类型并解析数据
    switch (motor->motor_type) {
        case MOTOR_TYPE_M2006:
            // M2006电机
            motor->status.m2006.angle_deg = ((data[0] << 8) | data[1]) * 360.0f / 8192.0f;  // 角度
            motor->status.m2006.speed_rpm = (data[2] << 8 | data[3]);  // 转速
            motor->status.m2006.current_a = (data[4] << 8 | data[5]) / 1000.0f;  // 电流
            motor->status.m2006.error_code = data[7];  // 错误码
            break;

        case MOTOR_TYPE_M3508:
            // M3508电机
            motor->status.m3508.angle_deg = ((data[0] << 8) | data[1]) * 360.0f / 8192.0f;  // 角度
            motor->status.m3508.speed_rpm = (data[2] << 8 | data[3]);  // 转速
            motor->status.m3508.current_a = (data[4] << 8 | data[5]) / 1000.0f;  // 电流
            motor->status.m3508.temperature_c = data[6];  // 温度，单位
            motor->status.m3508.error_code = data[7];  // 错误码
            break;

        case MOTOR_TYPE_GM6020:
            // GM6020电机
            motor->status.gm6020.angle_deg = ((data[0] << 8) | data[1]) * 360.0f / 8192.0f;  // 角度
            motor->status.gm6020.speed_rpm = (data[2] << 8 | data[3]);  // 转速
            motor->status.gm6020.current_a = (data[4] << 8 | data[5]) / 1000.0f;  // 电流
            motor->status.gm6020.temperature_c = data[6];  // 温度，单位
            break;

        default:
            // 错误处理
            break;
    }
}

// 电机类型选择函数
void Motor_Select(Motor* motor, uint8_t motor_type) {
    // 更新电机类型
    motor->motor_type = motor_type;
    // 重新初始化电机的状态
    Motor_Init(motor, motor_type);
}

// 输入电流控制函数A (控制1-4号电调)
void Motor_SetCurrentA(CAN_HandleTypeDef* hcan, Motor *motor, float iq1, float iq2, float iq3, float iq4) {
    uint8_t data[8];  // 用来存储要发送的数据
    int16_t current_val;  // 电流值转换为 16 位整数

    // 根据电机类型来判断电流值发送的格式
    switch (motor->motor_type) {
        case MOTOR_TYPE_M2006:
            // M2006电机
            current_val = (int16_t)(iq1 * 1000);
            if (current_val > 10000) current_val = 10000;
            if (current_val < -10000) current_val = -10000;
            data[0] = (current_val >> 8) & 0xFF;
            data[1] = current_val & 0xFF;

            current_val = (int16_t)(iq2 * 1000);
            if (current_val > 10000) current_val = 10000;
            if (current_val < -10000) current_val = -10000;
            data[2] = (current_val >> 8) & 0xFF;
            data[3] = current_val & 0xFF;

            current_val = (int16_t)(iq3 * 1000);
            if (current_val > 10000) current_val = 10000;
            if (current_val < -10000) current_val = -10000;
            data[4] = (current_val >> 8) & 0xFF;
            data[5] = current_val & 0xFF;

            current_val = (int16_t)(iq4 * 1000);
            if (current_val > 10000) current_val = 10000;
            if (current_val < -10000) current_val = -10000;
            data[6] = (current_val >> 8) & 0xFF;
            data[7] = current_val & 0xFF;

            CAN_Send(hcan, 0x200, data, 8, 0);
            break;

        case MOTOR_TYPE_M3508:
            // M3508电机
            current_val = (int16_t)(iq1 / 20 * 16384);
            if (current_val > 16384) current_val = 16384;
            if (current_val < -16384) current_val = -16384;
            data[0] = (current_val >> 8) & 0xFF;
            data[1] = current_val & 0xFF;

            current_val = (int16_t)(iq2 / 20 * 16384);
            if (current_val > 16384) current_val = 16384;
            if (current_val < -16384) current_val = -16384;
            data[2] = (current_val >> 8) & 0xFF;
            data[3] = current_val & 0xFF;

            current_val = (int16_t)(iq3 / 20 * 16384);
            if (current_val > 16384) current_val = 16384;
            if (current_val < -16384) current_val = -16384;
            data[4] = (current_val >> 8) & 0xFF;
            data[5] = current_val & 0xFF;

            current_val = (int16_t)(iq4 / 20 * 16384);
            if (current_val > 16384) current_val = 16384;
            if (current_val < -16384) current_val = -16384;
            data[6] = (current_val >> 8) & 0xFF;
            data[7] = current_val & 0xFF;

            CAN_Send(hcan, 0x200, data, 8, 0);
            break;

        default:
            // 错误处理
            break;
    }
}

// 输入电流控制函数B (控制5-8号电调)
void Motor_SetCurrentB(CAN_HandleTypeDef* hcan, Motor *motor, float iq1, float iq2, float iq3, float iq4) {
    uint8_t data[8];  // 用来存储要发送的数据
    int16_t current_val;  // 电流值转换为 16 位整数

    // 根据电机类型来判断电流值发送的格式
    switch (motor->motor_type) {
        case MOTOR_TYPE_M2006:
            // M2006电机
            current_val = (int16_t)(iq1 * 1000);
            if (current_val > 10000) current_val = 10000;
            if (current_val < -10000) current_val = -10000;
            data[0] = (current_val >> 8) & 0xFF;
            data[1] = current_val & 0xFF;

            current_val = (int16_t)(iq2 * 1000);
            if (current_val > 10000) current_val = 10000;
            if (current_val < -10000) current_val = -10000;
            data[2] = (current_val >> 8) & 0xFF;
            data[3] = current_val & 0xFF;

            current_val = (int16_t)(iq3 * 1000);
            if (current_val > 10000) current_val = 10000;
            if (current_val < -10000) current_val = -10000;
            data[4] = (current_val >> 8) & 0xFF;
            data[5] = current_val & 0xFF;

            current_val = (int16_t)(iq4 * 1000);
            if (current_val > 10000) current_val = 10000;
            if (current_val < -10000) current_val = -10000;
            data[6] = (current_val >> 8) & 0xFF;
            data[7] = current_val & 0xFF;

            CAN_Send(hcan, 0x1FF, data, 8, 0);
            break;

        case MOTOR_TYPE_M3508:
            // M3508电机
            current_val = (int16_t)(iq1 / 20 * 16384);
            if (current_val > 16384) current_val = 16384;
            if (current_val < -16384) current_val = -16384;
            data[0] = (current_val >> 8) & 0xFF;
            data[1] = current_val & 0xFF;

            current_val = (int16_t)(iq2 / 20 * 16384);
            if (current_val > 16384) current_val = 16384;
            if (current_val < -16384) current_val = -16384;
            data[2] = (current_val >> 8) & 0xFF;
            data[3] = current_val & 0xFF;

            current_val = (int16_t)(iq3 / 20 * 16384);
            if (current_val > 16384) current_val = 16384;
            if (current_val < -16384) current_val = -16384;
            data[4] = (current_val >> 8) & 0xFF;
            data[5] = current_val & 0xFF;

            current_val = (int16_t)(iq4 / 20 * 16384);
            if (current_val > 16384) current_val = 16384;
            if (current_val < -16384) current_val = -16384;
            data[6] = (current_val >> 8) & 0xFF;
            data[7] = current_val & 0xFF;

            CAN_Send(hcan, 0x1FF, data, 8, 0);
            break;

        default:
            // 错误处理
            break;
    }
}

// 输入电压控制函数A (控制1-4号电调)
void Motor_SetVoltageA(CAN_HandleTypeDef* hcan, Motor *motor, float iu1, float iu2, float iu3, float iu4) {
    uint8_t data[8];  // 用来存储要发送的数据
    int16_t voltage_val;  // 电压值转换为 16 位整数

    // 根据电机类型来判断电压值发送的格式
    switch (motor->motor_type) {
        case MOTOR_TYPE_GM6020:
            // GM6020电机
            voltage_val = (int16_t)(iu1 * 1000);
            if (voltage_val > 25000) voltage_val = 25000;
            if (voltage_val < -25000) voltage_val = -25000;
            data[0] = (voltage_val >> 8) & 0xFF;
            data[1] = voltage_val & 0xFF;

            voltage_val = (int16_t)(iu2 * 1000);
            if (voltage_val > 25000) voltage_val = 25000;
            if (voltage_val < -25000) voltage_val = -25000;
            data[2] = (voltage_val >> 8) & 0xFF;
            data[3] = voltage_val & 0xFF;

            voltage_val = (int16_t)(iu3 * 1000);
            if (voltage_val > 25000) voltage_val = 25000;
            if (voltage_val < -25000) voltage_val = -25000;
            data[4] = (voltage_val >> 8) & 0xFF;
            data[5] = voltage_val & 0xFF;

            voltage_val = (int16_t)(iu4 * 1000);
            if (voltage_val > 25000) voltage_val = 25000;
            if (voltage_val < -25000) voltage_val = -25000;
            data[6] = (voltage_val >> 8) & 0xFF;
            data[7] = voltage_val & 0xFF;

            CAN_Send(hcan, 0x1FF, data, 8, 0);
            break;

        default:
            // 错误处理
            break;
    }
}

// 输入电压控制函数B (控制5-7号电调)
void Motor_SetVoltageB(CAN_HandleTypeDef* hcan, Motor *motor, float iu1, float iu2, float iu3) {
    uint8_t data[8];  // 用来存储要发送的数据
    int16_t voltage_val;  // 电压值转换为 16 位整数

    // 根据电机类型来判断电压值发送的格式
    switch (motor->motor_type) {
        case MOTOR_TYPE_GM6020:
            // GM6020电机
            voltage_val = (int16_t)(iu1 * 1000);
            if (voltage_val > 25000) voltage_val = 25000;
            if (voltage_val < -25000) voltage_val = -25000;
            data[0] = (voltage_val >> 8) & 0xFF;
            data[1] = voltage_val & 0xFF;

            voltage_val = (int16_t)(iu2 * 1000);
            if (voltage_val > 25000) voltage_val = 25000;
            if (voltage_val < -25000) voltage_val = -25000;
            data[2] = (voltage_val >> 8) & 0xFF;
            data[3] = voltage_val & 0xFF;

            voltage_val = (int16_t)(iu3 * 1000);
            if (voltage_val > 25000) voltage_val = 25000;
            if (voltage_val < -25000) voltage_val = -25000;
            data[4] = (voltage_val >> 8) & 0xFF;
            data[5] = voltage_val & 0xFF;

            data[6] = 0;
            data[7] = 0;

            CAN_Send(hcan, 0x2FF, data, 8, 0);
            break;  

        default:
            // 错误处理
            break;
    }
}
