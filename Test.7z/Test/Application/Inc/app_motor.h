#ifndef APP_MOTOR_H
#define APP_MOTOR_H

#ifdef __cplusplus
extern "C" {
#endif

/* ========== 包含头文件 ========== */

#include "app_config.h"
#include "bsp_config.h"
#include "bsp_can.h"

/* ========== 函数声明 ========== */

// 针对其它厂家的电机类型，可以通过修改app_config.h中的电机结构体来添加支持，同时在app_motor.c与此文件中添加对应的处理函数即可

// 目前支持的电机类型包括：M2006、M3508、GM6020

// 电机初始化函数
void Motor_Init(Motor *motor, uint8_t motor_type);

// 电机状态更新函数
void Motor_UpdateStatus(Motor *motor, uint8_t* data);

// 电机类型选择函数
void Motor_Select(Motor *motor, uint8_t motor_type);

// 输入电流控制函数A (控制1-4号电调)
void Motor_SetCurrentA(CAN_HandleTypeDef* hcan, Motor *motor, float iq1, float iq2, float iq3, float iq4);

// 输入电流控制函数B (控制5-8号电调)
void Motor_SetCurrentB(CAN_HandleTypeDef* hcan, Motor *motor, float iq1, float iq2, float iq3, float iq4);

// 输入电压控制函数A (控制1-4号电调)
void Motor_SetVoltageA(CAN_HandleTypeDef* hcan, Motor *motor, float iu1, float iu2, float iu3, float iu4);

// 输入电压控制函数B (控制5-7号电调)
void Motor_SetVoltageB(CAN_HandleTypeDef* hcan, Motor *motor, float iu1, float iu2, float iu3); // 注意，GM6020最高只有7号电调，所以Data[6]和Data[7]留空

#ifdef __cplusplus
}
#endif

#endif