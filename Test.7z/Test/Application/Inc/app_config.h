#ifndef APP_CONFIG_H
#define APP_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

/* ========== 包含头文件 ========== */

#include <stdint.h>
#include <stddef.h>

/* ========== 宏定义 ========== */

// 电机类型定义
#define MOTOR_TYPE_M2006  1
#define MOTOR_TYPE_M3508  2
#define MOTOR_TYPE_GM6020 3

/* ========== 数据类型定义 ========== */

// 电机状态结构体
typedef struct {
    float angle_deg;   // 电机角度
    int16_t speed_rpm; // 电机转速
    float current_a;   // 电机电流
    int8_t error_code; // 电机错误码
} M2006_Motor_Status;

typedef struct {
    float angle_deg;   // 电机角度
    int16_t speed_rpm; // 电机转速
    float current_a;   // 电机电流
    int8_t temperature_c; // 电机温度
    int8_t error_code; // 电机错误码
} M3508_Motor_Status;

typedef struct {
    float angle_deg;   // 电机角度
    int16_t speed_rpm; // 电机转速
    float current_a;   // 电机电流
    int8_t temperature_c; // 电机温度
} GM6020_Motor_Status;

typedef union {
    M2006_Motor_Status m2006;
    M3508_Motor_Status m3508;
    GM6020_Motor_Status gm6020;
} Motor_Status_Union;

typedef struct {
    uint8_t motor_type;   // 电机类型（M2006、M3508、GM6020）
    Motor_Status_Union status;  // 电机状态
} Motor;

/* ========== 全局变量声明 ========== */

extern Motor motor1;

#ifdef __cplusplus
}
#endif

#endif